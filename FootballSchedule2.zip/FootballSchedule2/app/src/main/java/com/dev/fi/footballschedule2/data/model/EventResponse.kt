package com.dev.fi.footballschedule2.data.model

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

data class EventResponse(
        val events: List<Event>)