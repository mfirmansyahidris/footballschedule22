package com.dev.fi.footballschedule2.ui.detailMatch

import com.dev.fi.footballschedule2.data.model.Event

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

interface DetailMatchV {
    fun showDetail(data: Event)
}