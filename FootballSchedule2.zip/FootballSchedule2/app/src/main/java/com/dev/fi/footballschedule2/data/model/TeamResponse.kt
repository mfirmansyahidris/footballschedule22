package com.dev.fi.footballschedule2.data.model

/**
 ****************************************
created by -manca-
.::manca.fi@gmail.com ::.
 ****************************************
 */

data class TeamResponse(
        val teams: List<Team>)